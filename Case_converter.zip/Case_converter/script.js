const textArea = document.querySelector("#textarea");
const upperCaseBtn = document.querySelector("#upper-case");
const lowerCaseBtn = document.querySelector("#lower-case");
const properCaseBtn = document.querySelector("#proper-case");
const sentenceCaseBtn = document.querySelector("#sentence-case");
const saveTextFile = document.querySelector("#save-text-file");

function uppCaseButton () {

    textArea.value = textArea.value.toUpperCase();
}

function lowerCaseButton () {
    textArea.value = textArea.value.toLowerCase();
}

function properCaseButton () {
const string = textArea.value;
const words = string.split(" ");

const result = words.map((word) =>{
  return  word[0].toUpperCase() + word.slice(1);
})

textArea.value = result.join(" ");
}

function sentenceCaseButton () {
  const string = textArea.value;
  const sentences = string.split(". ");

  const result = sentences.map((item) =>{
    return item[0].toUpperCase() + item.slice(1).toLowerCase();
  })

  textArea.value = result.join(". ");
}

  function download(filename, text) {
    let element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);

    element.style.display = 'none';
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
}




upperCaseBtn.addEventListener("click", uppCaseButton);

lowerCaseBtn.addEventListener("click", lowerCaseButton);

properCaseBtn.addEventListener("click", properCaseButton);

sentenceCaseBtn.addEventListener("click", sentenceCaseButton);

saveTextFile.addEventListener("click", function () {
  let text = document.getElementById("textarea").value;
  let filename = "text.txt"
  download(filename ,text);
}, false);
